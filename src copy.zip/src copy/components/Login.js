import React from 'react';
import axios from 'axios'
import {Link} from 'react-router-dom'
import $ from "jquery"
class Login extends React.Component {
  state = {
    userReceived: []
  }
  login () {
    const email = $("#email").val()
    const password = $("#password").val()
    const request = {"auth": {"email": email, "password": password}}
    $.ajax({
      url: "http://localhost:3000/api/user_token",
      type: "POST",
      data: request,
      dataType: "json",
      success: function (result) {
        localStorage.setItem("jwt", result.jwt)
      }
    })
  }
  getUser(admin) {
    let token = "Bearer " + localStorage.getItem("jwt")
    let url = ""
    url = admin ? "http://localhost:3000/api/users" : "http://localhost:3000/api/users/5"
    axios.get(url, { params:{}, headers: { 'Authorization': token } })
    .then(res => {
      console.log(res);
      this.setState({userReceived: res.data})
      console.log(this.state.userReceived);
    })
    .catch(console.warn())
  }
  render() {
      return (
        <div className="App">
          <h1 style={{marginTop: "20vh", marginBottom: "5vh"}}>
          Get appointments
          </h1>
          <form>
            <label htmlFor="email">Email: </label>
            <br />
            <input
              name="email"
              id="email"
              type="email"
            />
            <br /><br />
            <label htmlFor="password">Password:</label>
            <br />
            <input
              name="password"
              id="password"
              type="password"
            />
            </form>
            <br />
            <button onClick={this.login}>Login</button>
          <br />
          <button onClick={() => this.getUser(true)} style={{marginTop: "10vh"}}>Get User</button>
          <p>{this.state.appointmentsReceived}</p>
        </div>
      );
    }
  }
export default Login;
