import React from "react"
import Calendar from "./Calendar"
import ShowDate from "./ShowDate"
import ShowEvent from "./ShowEvent"
import axios from "axios"
import CreateAppointment from "./CreateAppointment"
import ShowCalendar from "./ShowCalendar"
import {
  Route,
  Link,
  HashRouter as Router,
  Switch
} from "react-router-dom"
class Main extends React.Component {
  render(){
    return(
      <div>
        <Router>
          <Route exact path="/" component={ShowCalendar}></Route>
          <Route exact path="/calendar/:day/:month/:year/create/appointment" component={CreateAppointment}></Route>
          <Route exact path="/calendar/:day/:month/:year" component={ShowDate}></Route>
          <Route exact path="/calendar/:day/:month/:year/:event" component={ShowEvent}></Route>
        </Router>
      </div>
    )
  }
}

export default Main
