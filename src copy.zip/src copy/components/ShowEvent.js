import React from "react"
import axios from "axios"
const APPOINTMENT_URL = `http://localhost:3000/appointments.json`
const USER_URL = `http://localhost:3000/users.json`

class ShowEvent extends React.Component {
  state = {
    appointments: [],
    appointment: [],
  }
  componentDidMount(){
    const {match: {params: {day, month, year, appointment_id}}} = this.props;
    this.fetchAppointments();
    this.fetchUser()
  }
  fetchAppointments() {
    axios.get(APPOINTMENT_URL)
    .then(res => {
      this.setState({appointments: res.data});
      console.log(this.state.appointments)
      this.findAppointment()
    })
    .catch(error => console.warn(error));
  }
  fetchUser() {
    axios.get(USER_URL)
    .then(res => {
      console.log(res)
    })
  }
  findAppointment() {
    let result = this.state.appointments.filter(x => (x.date === `${this.props.match.params.year}-${this.props.match.params.month}-${this.props.match.params.day}`) && (x.id === parseInt(this.props.match.params.event)))
    this.setState({appointment: result})
    console.log(parseInt(this.props.match.params.event));
    console.log(this.state.appointment[0].id)
  }
  render(){
    return(
      <div>
        <div>Title:</div>
        <div>Description:</div>
        <div>Time:</div>
        <div>Date:</div>
        <div>MAPS:</div>
        <div>ATTENDEES:</div>
      </div>
    )
  }
}

export default ShowEvent
