import React from "react"
import axios from "axios"
import "../App.css"
import {
  Route,
  Link,
  HashRouter as Router
} from "react-router-dom"
import TimePicker from "react-time-picker"
import CreateAppointment from "./CreateAppointment"
const APPOINTMENT_URL = `http://localhost:3000/appointments.json`
class ShowDate extends React.Component {
  state = {
    appointments: [],
    appointmentsToday: [],
    time: ""
  }
  componentDidMount() {
    const {match: {params: {day, month, year}}} = this.props;
    this.fetchAppointments();
    this.changeTime();
  }
  changeTime() {
    let counting = setInterval(()=>{
      let newTime = new Date().getTime();
      let properTime = new Date(newTime).toTimeString().substr(0,8)
      this.setState({time: properTime})
    }, 500)
  }
  fetchAppointments() {
    axios.get(APPOINTMENT_URL)
    .then(res => {
      this.setState({appointments: res.data});
      console.log(res.data);
      this.findAppointmentsToday();
    })
    .catch(error => console.warn(error));
  }
  findAppointmentsToday() {
    let result = this.state.appointments.filter(x => x.date === `${this.props.match.params.year}-${this.props.match.params.month}-${this.props.match.params.day}`)
    this.setState({appointmentsToday: result})
    this.renderAppointmentsToday()
  }
  renderAppointmentsToday() {
    let times = document.getElementsByClassName("timeOfDay")
    for(let i = 0; i < this.state.appointmentsToday.length; i++) {
      for(let x = 0; x < times.length; x++) {
        if((this.state.appointmentsToday[i].time.substr(11,2) === times[x].innerText.substr(0,2)) && (this.state.appointmentsToday[i].aside === times[x].innerText.substr(2,2)) ) {
          times[x].classList.add("highlight")
          times[x].addEventListener("click", (event) => {
            this.props.history.push(`${this.props.history.location.pathname}/${this.state.appointmentsToday[i].id}`)
          })
        }
      }
    }
  }
  linkToCreate = () => {
    this.props.history.push(`/calendar/${this.props.match.params.day}/${this.props.match.params.month}/${this.props.match.params.year}/create/appointment`)
  }
  render(){
    return(
      <div className="dateTime">
        <div id="Time" className="timeOfDay"><span>Date:{this.props.match.params.day}/{this.props.match.params.month}/{this.props.match.params.year}<h1>{this.state.time}</h1></span></div>
        <div onClick={this.linkToCreate}>+</div>
        <div id="12am" className="timeOfDay">12am</div>
        <div id="01am" className="timeOfDay">01am</div>
        <div id="02am" className="timeOfDay">02am</div>
        <div id="03am" className="timeOfDay">03am</div>
        <div id="04am" className="timeOfDay">04am</div>
        <div id="05am" className="timeOfDay">05am</div>
        <div id="06am" className="timeOfDay">06am</div>
        <div id="07am" className="timeOfDay">07am</div>
        <div id="08am" className="timeOfDay">08am</div>
        <div id="09am" className="timeOfDay">09am</div>
        <div id="10am" className="timeOfDay">10am</div>
        <div id="11am" className="timeOfDay">11am</div>
        <div id="12pm" className="timeOfDay">12pm</div>
        <div id="01pm" className="timeOfDay">01pm</div>
        <div id="02pm" className="timeOfDay">02pm</div>
        <div id="03pm" className="timeOfDay">03pm</div>
        <div id="04pm" className="timeOfDay">04pm</div>
        <div id="05pm" className="timeOfDay">05pm</div>
        <div id="06pm" className="timeOfDay">06pm</div>
        <div id="07pm" className="timeOfDay">07pm</div>
        <div id="08pm" className="timeOfDay">08pm</div>
        <div id="09pm" className="timeOfDay">09pm</div>
        <div id="10pm" className="timeOfDay">10pm</div>
        <div id="11pm" className="timeOfDay bottomBorder">11pm</div>
      </div>
    )
  }
}

export default ShowDate
