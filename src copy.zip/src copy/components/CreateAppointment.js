import React from "react"
import axios from "axios"
const APPOINTMENT_URL = `http://localhost:3000/appointments`
class CreateAppointment extends React.Component {
  constructor (props) {
    super(props);
    this.state = {
      title: "",
      description: "",
      time: "",
      timeTo: "",
      aside: "",
      asideTo: "",
      address: "",
      date: ""
    };
  }
  saveAppointment = () => {
    axios.post(APPOINTMENT_URL,{title: this.state.title, description:this.state.description, address:this.state.address, date:this.state.date, time:this.state.time, timeTo:this.state.timeTo, aside:this.state.aside, asideTo:this.state.asideTo})
    .then(res => {
      return res
    })
  }
  handleChange = (event) => {
    if(event.target.name === "time") {
      console.log(event.target.value);
      if(parseInt(event.target.value.substr(0,2)) > 12) {
        console.log(event.target.value);
        this.setState({time: event.target.value, aside: "pm"})
      } else {
        this.setState({time: event.target.value, aside:"am"})
      }
    } else if(event.target.name === "timeTo") {
      if(parseInt(event.target.value.substr(0,2)) > 12) {
        this.setState({timeTo: event.target.value, asideTo: "pm"})
      } else {
        this.setState({timeTo: event.target.value, asideTo:"am"})
      }
    } else{
      this.setState({ [event.target.name]: event.target.value });
    }
  }
  handleSubmit = (event) => {
    const {match: {params: {day, month, year}}} = this.props;
    this.setState({date: `${day}-${month}-${year}`})
    this.saveAppointment();
    this.goBack()
    event.preventDefault();
  }
  goBack = () => {
    const {match: {params: {day, month, year}}} = this.props;
    this.props.history.push(`/calendar/${day}/${month}/${year}/`)
  }
  render(){
    // console.log(this.props.params)
    return(
      <div>
        <h1> ITS ALIVE </h1>
        <button onClick = {this.goBack}>Back</button>
        <form onSubmit={this.handleSubmit}>
          <input type="text" name="title" placeholder="Title" onChange={this.handleChange}></input><br/>
          <input type="text" name="description" placeholder="Description" onChange={this.handleChange}></input><br/>
          <input type="text" name="address" placeholder="Address" onChange={this.handleChange}></input><br/>
          <input type="time" name="time" placeholder="Time" onChange={this.handleChange}></input><br/>
          <input type="time" name="timeTo" placeholder="TimeTo" onChange={this.handleChange}></input><br/>
          <input type="submit" onSubmit={this.handleSubmit} value="Make Appointment"></input>
        </form>
      </div>
    );//return
  }
}
export default CreateAppointment;
